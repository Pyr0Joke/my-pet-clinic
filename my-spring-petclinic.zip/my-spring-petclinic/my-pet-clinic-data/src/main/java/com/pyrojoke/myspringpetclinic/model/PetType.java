package com.pyrojoke.myspringpetclinic.model;

public class PetType extends BaseEntity{
    private String type;



    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}

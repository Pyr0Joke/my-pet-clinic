package com.pyrojoke.myspringpetclinic.model;

public class Vet extends Person {
}

package com.pyrojoke.myspringpetclinic.services;

import com.pyrojoke.myspringpetclinic.model.Vet;

import java.util.Set;

public interface VetService extends CrudService<Vet, Long>{
}

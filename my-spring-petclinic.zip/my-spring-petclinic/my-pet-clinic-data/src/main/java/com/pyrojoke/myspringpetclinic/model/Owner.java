package com.pyrojoke.myspringpetclinic.model;

public class Owner extends Person  {
}

package com.pyrojoke.myspringpetclinic.bootstrap;

import com.pyrojoke.myspringpetclinic.model.Owner;
import com.pyrojoke.myspringpetclinic.model.Vet;
import com.pyrojoke.myspringpetclinic.services.*;
import com.pyrojoke.myspringpetclinic.services.map.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    private final OwnerService ownerService;
    private final VetService vetService;

    public DataLoader(OwnerService ownerService, VetService vetService) {
        this.ownerService = ownerService;
        this.vetService = vetService;
    }

    @Override
    public void run(String... args) throws Exception {
        Owner owner1 = new Owner();
        owner1.setFirstName("Sasha");
        owner1.setLastName("Lipatov");
        Owner owner2 = new Owner();
        owner2.setFirstName("Vadim");
        owner2.setLastName("Tekuev");
        Owner owner3 = new Owner();
        owner3.setFirstName("Anton");
        owner3.setLastName("Vasilev");
        ownerService.save(owner1);
        ownerService.save(owner2);
        ownerService.save(owner3);

        System.out.println("loaded owners..");

        Vet vet1 = new Vet();
        Vet vet2 = new Vet();
        Vet vet3 = new Vet();

        vet1.setFirstName("Ivan");
        vet1.setLastName("Ivanov");
        vet2.setFirstName("Petr");
        vet2.setLastName("Petrov");
        vet3.setFirstName("Vasya");
        vet3.setLastName("Vasyilev");;

        vetService.save(vet1);
        vetService.save(vet2);
        vetService.save(vet3);

        System.out.println("loaded vets..");


    }
}
